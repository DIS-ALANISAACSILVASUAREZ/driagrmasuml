
import java.util.*;

/**
 * 
 */
public class shopping cart {

    /**
     * Default constructor
     */
    public shopping cart() {
    }

    /**
     * 
     */
    public void id;

    /**
     * 
     */
    public void producto;

    /**
     * 
     */
    public void add-producto() {
        // TODO implement here
    }

    /**
     * 
     */
    public void remove-producto() {
        // TODO implement here
    }

    /**
     * 
     */
    public void checkout() {
        // TODO implement here
    }

}