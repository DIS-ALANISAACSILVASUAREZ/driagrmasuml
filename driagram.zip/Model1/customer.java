
import java.util.*;

/**
 * 
 */
public class customer extends user {

    /**
     * Default constructor
     */
    public customer() {
    }

    /**
     * 
     */
    public void name;

    /**
     * 
     */
    public void illingaddress;

    /**
     * 
     */
    public void default;

    /**
     * 
     */
    public void singup() {
        // TODO implement here
    }

    /**
     * 
     */
    public void login() {
        // TODO implement here
    }

}