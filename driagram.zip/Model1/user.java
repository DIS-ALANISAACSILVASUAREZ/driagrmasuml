
import java.util.*;

/**
 * 
 */
public class user {

    /**
     * Default constructor
     */
    public user() {
    }

    /**
     * 
     */
    public void id;

    /**
     * 
     */
    public void email;

    /**
     * 
     */
    public void password;

    /**
     * 
     */
    public void login;

    /**
     * 
     */
    public void getSession() {
        // TODO implement here
    }

}