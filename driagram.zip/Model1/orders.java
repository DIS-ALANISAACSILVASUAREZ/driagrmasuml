
import java.util.*;

/**
 * 
 */
public class orders {

    /**
     * Default constructor
     */
    public orders() {
    }

    /**
     * 
     */
    public void id;

    /**
     * 
     */
    public void costo;

    /**
     * 
     */
    public void orderdate;

    /**
     * 
     */
    public void status;

    /**
     * 
     */
    public void price;

    /**
     * 
     */
    public void updateOrder() {
        // TODO implement here
    }

    /**
     * 
     */
    public void placeorder() {
        // TODO implement here
    }

    /**
     * 
     */
    public void cancelorder() {
        // TODO implement here
    }

}