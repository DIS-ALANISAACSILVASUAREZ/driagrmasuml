
import java.util.*;

/**
 * 
 */
public class order detalls {

    /**
     * Default constructor
     */
    public order detalls() {
    }

    /**
     * 
     */
    public void id;

    /**
     * 
     */
    public void orderld;

    /**
     * 
     */
    public void address;

    /**
     * 
     */
    public void costo;

    /**
     * 
     */
    public void create;

    /**
     * 
     */
    public void cancelar order() {
        // TODO implement here
    }

}