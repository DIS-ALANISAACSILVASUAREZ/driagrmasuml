
import java.util.*;

/**
 * 
 */
public class sistema {

    /**
     * Default constructor
     */
    public sistema() {
    }

    /**
     * 
     */
    public void datos_usuario;

    /**
     * 
     */
    public void actualizar;

    /**
     * 
     */
    public void mantenimiento_pagina;


}