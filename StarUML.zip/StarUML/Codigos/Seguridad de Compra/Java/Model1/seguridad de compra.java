
import java.util.*;

/**
 * 
 */
public class seguridad de compra {

    /**
     * Default constructor
     */
    public seguridad de compra() {
    }


    /**
     * 
     */
    public void comprar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void seguridad_de_datos_tarjeta() {
        // TODO implement here
    }

    /**
     * 
     */
    public void datos_usuario() {
        // TODO implement here
    }

    /**
     * 
     */
    public void NO_difundir_informacion() {
        // TODO implement here
    }

    /**
     * 
     */
    public void actualizar_datos() {
        // TODO implement here
    }

}