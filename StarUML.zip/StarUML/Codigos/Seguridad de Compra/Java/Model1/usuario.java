
import java.util.*;

/**
 * 
 */
public class usuario {

    /**
     * Default constructor
     */
    public usuario() {
    }

    /**
     * 
     */
    public void cuenta;

    /**
     * 
     */
    public void direccion;

    /**
     * 
     */
    public void stock;

    /**
     * 
     */
    public void compra() {
        // TODO implement here
    }

    /**
     * 
     */
    public void seguridad_tarjeta() {
        // TODO implement here
    }

    /**
     * 
     */
    public void NIP() {
        // TODO implement here
    }

}