#!/usr/bin/python
#-*- coding: utf-8 -*-

class seguridad de compra:
    def __init__(self):

    def comprar(self, ):
        pass

    def seguridad_de_datos_tarjeta(self, ):
        pass

    def datos_usuario(self, ):
        pass

    def NO_difundir_informacion(self, ):
        pass

    def actualizar_datos(self, ):
        pass

