#!/usr/bin/python
#-*- coding: utf-8 -*-

class categoria de producto:
    def __init__(self):

    def numeros de categoria(self, ):
        pass

    def eliminar(self, ):
        pass

    def preparar(self, ):
        pass

    def registrar(self, ):
        pass

    def modificar(self, ):
        pass

