#!/usr/bin/python
#-*- coding: utf-8 -*-

class usuario:
    def __init__(self):

    def validar(self, ):
        pass

    def visualizar_usuario(self, ):
        pass

    def modificar_usuario(self, ):
        pass

