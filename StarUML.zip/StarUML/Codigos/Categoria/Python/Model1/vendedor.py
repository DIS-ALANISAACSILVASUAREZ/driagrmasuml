#!/usr/bin/python
#-*- coding: utf-8 -*-

class vendedor:
    def __init__(self):

    def visualizar(self, ):
        pass

    def modificar(self, ):
        pass

    def obtener_NumVendedro(self, ):
        pass

