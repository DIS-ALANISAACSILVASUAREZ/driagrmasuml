#!/usr/bin/python
#-*- coding: utf-8 -*-

class producto:
    def __init__(self):

    def registra(self, ):
        pass

    def preparar(self, ):
        pass

    def stock(self, ):
        pass

    def marca(self, ):
        pass

    def precio(self, ):
        pass

