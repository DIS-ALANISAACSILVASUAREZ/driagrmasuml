#!/usr/bin/python
#-*- coding: utf-8 -*-

class cliente:
    def __init__(self):
        pass

    def validar(self, ):
        pass

    def registrar(self, ):
        pass

    def visualizar_cliente(self, ):
        pass

    def modificar_cliente(self, ):
        pass

    def obtener_NumCliente(self, ):
        pass

