
import java.util.*;

/**
 * 
 */
public class producto {

    /**
     * Default constructor
     */
    public producto() {
    }




    /**
     * 
     */
    public void registra() {
        // TODO implement here
    }

    /**
     * 
     */
    public void preparar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void stock() {
        // TODO implement here
    }

    /**
     * 
     */
    public void marca() {
        // TODO implement here
    }

    /**
     * 
     */
    public void precio() {
        // TODO implement here
    }

}