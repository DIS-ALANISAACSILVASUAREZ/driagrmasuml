
import java.util.*;

/**
 * 
 */
public class pedido {

    /**
     * Default constructor
     */
    public pedido() {
    }


    /**
     * 
     */
    public void registrar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void obtener_numPedido() {
        // TODO implement here
    }

}