
import java.util.*;

/**
 * 
 */
public class cliente {

    /**
     * Default constructor
     */
    public cliente() {
    }

    /**
     * 
     */
    public void validar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void registrar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void visualizar_cliente() {
        // TODO implement here
    }

    /**
     * 
     */
    public void modificar_cliente() {
        // TODO implement here
    }

    /**
     * 
     */
    public void obtener_NumCliente() {
        // TODO implement here
    }

}