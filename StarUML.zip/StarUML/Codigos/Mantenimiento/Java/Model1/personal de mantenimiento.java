
import java.util.*;

/**
 * 
 */
public class personal de mantenimiento {

    /**
     * Default constructor
     */
    public personal de mantenimiento() {
    }

    /**
     * 
     */
    public void cuenta;

    /**
     * 
     */
    public void registra;

    /**
     * 
     */
    public void elimina;

    /**
     * 
     */
    public void buscar;

    /**
     * 
     */
    public void stock;

    /**
     * 
     */
    public void reportes;

}