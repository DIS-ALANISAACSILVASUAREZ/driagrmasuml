
import java.util.*;

/**
 * 
 */
public class mantenimiento {

    /**
     * Default constructor
     */
    public mantenimiento() {
    }

    /**
     * 
     */
    public void stock;

    /**
     * 
     */
    public void descripcion;

    /**
     * 
     */
    public void buscar;

    /**
     * 
     */
    public void elimina;

    /**
     * 
     */
    public void modifica;


    /**
     * 
     */
    public void genera reportes de mantenimiento() {
        // TODO implement here
    }

}