#!/usr/bin/python
#-*- coding: utf-8 -*-

class mantenimiento:
    def __init__(self):
        self.stock = None
        self.descripcion = None
        self.buscar = None
        self.elimina = None
        self.modifica = None

    def genera reportes de mantenimiento(self, ):
        pass

