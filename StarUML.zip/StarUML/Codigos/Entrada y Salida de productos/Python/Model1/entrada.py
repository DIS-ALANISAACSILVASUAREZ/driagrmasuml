#!/usr/bin/python
#-*- coding: utf-8 -*-

class entrada:
    def __init__(self):
        self.id_entrada = None
        self.valor_unidad = None
        self.fecha = None
        self.factura = None
        self.cantidad = None
        self.id_articulo = None

    def ingresar(self, ):
        pass

    def modificar(self, ):
        pass

    def eliminar(self, ):
        pass

    def consultar(self, ):
        pass

    def validar_articulo(self, ):
        pass

