#!/usr/bin/python
#-*- coding: utf-8 -*-

class devoluciones:
    def __init__(self):
        self.id_devolucion = None
        self.cantidad = None
        self.id_articulo = None
        self.fecha = None

    def ingresar(self, ):
        pass

    def modificar(self, ):
        pass

    def eliminar(self, ):
        pass

    def consultar(self, ):
        pass

