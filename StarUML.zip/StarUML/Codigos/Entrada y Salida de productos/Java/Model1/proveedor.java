
import java.util.*;

/**
 * 
 */
public class proveedor {

    /**
     * Default constructor
     */
    public proveedor() {
    }

    /**
     * 
     */
    public void id_proveedor;

    /**
     * 
     */
    public void nombre;

    /**
     * 
     */
    public void documentos;

    /**
     * 
     */
    public void direccion;

    /**
     * 
     */
    public void correo;

    /**
     * 
     */
    public void telefono;


    /**
     * 
     */
    public void modificar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void consultar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void eliminar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void ingresar() {
        // TODO implement here
    }

}