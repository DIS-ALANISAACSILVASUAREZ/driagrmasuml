
import java.util.*;

/**
 * 
 */
public class entrada {

    /**
     * Default constructor
     */
    public entrada() {
    }

    /**
     * 
     */
    public void id_entrada;

    /**
     * 
     */
    public void valor_unidad;

    /**
     * 
     */
    public void fecha;

    /**
     * 
     */
    public void factura;

    /**
     * 
     */
    public void cantidad;

    /**
     * 
     */
    public void id_articulo;

    /**
     * 
     */
    public void ingresar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void modificar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void eliminar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void consultar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void validar_articulo() {
        // TODO implement here
    }

}