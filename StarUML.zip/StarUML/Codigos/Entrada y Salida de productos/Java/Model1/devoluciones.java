
import java.util.*;

/**
 * 
 */
public class devoluciones {

    /**
     * Default constructor
     */
    public devoluciones() {
    }

    /**
     * 
     */
    public void id_devolucion;

    /**
     * 
     */
    public void cantidad;

    /**
     * 
     */
    public void id_articulo;

    /**
     * 
     */
    public void fecha;


    /**
     * 
     */
    public void ingresar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void modificar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void eliminar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void consultar() {
        // TODO implement here
    }

}