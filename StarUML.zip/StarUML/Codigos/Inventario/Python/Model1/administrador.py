#!/usr/bin/python
#-*- coding: utf-8 -*-

class administrador:
    def __init__(self):
        self.modifica = None
        self.registra = None
        self.consulta = None
        self.desincorpora o incorpora = None
        self.genera reportes = None

