
import java.util.*;

/**
 * 
 */
public class administrador {

    /**
     * Default constructor
     */
    public administrador() {
    }

    /**
     * 
     */
    public void modifica;

    /**
     * 
     */
    public void registra;

    /**
     * 
     */
    public void consulta;

    /**
     * 
     */
    public void desincorpora o incorpora;

    /**
     * 
     */
    public void genera reportes;

}