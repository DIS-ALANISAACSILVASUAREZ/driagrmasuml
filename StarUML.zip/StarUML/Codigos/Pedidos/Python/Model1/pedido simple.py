#!/usr/bin/python
#-*- coding: utf-8 -*-

class pedido simple:
    def __init__(self):
        pass

    def obtener_total(self, ):
        pass

    def cobrar(self, ):
        pass

    def obtener_detalle(self, ):
        pass

