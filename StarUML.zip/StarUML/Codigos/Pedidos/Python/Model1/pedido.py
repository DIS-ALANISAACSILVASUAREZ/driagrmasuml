#!/usr/bin/python
#-*- coding: utf-8 -*-

class pedido:
    def __init__(self):
        self.total = None
        self.estado = None

    def cobrar(self, ):
        pass

    def confirmar(self, ):
        pass

    def obtener_total(self, ):
        pass

    def obtener_detalle(self, ):
        pass

    def añadir_pedido(self, ):
        pass

