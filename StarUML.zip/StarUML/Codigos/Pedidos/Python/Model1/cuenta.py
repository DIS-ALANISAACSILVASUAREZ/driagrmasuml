#!/usr/bin/python
#-*- coding: utf-8 -*-

class cuenta:
    def __init__(self):
        self.id_cuenta = None
        self.disponible = None
        self.Num_tarjeta = None

    def pagar_pedido(self, ):
        pass

