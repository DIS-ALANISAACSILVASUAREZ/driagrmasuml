#!/usr/bin/python
#-*- coding: utf-8 -*-

class pedido compuesto:
    def __init__(self):

    def obtener_total(self, ):
        pass

    def añadir(self, ):
        pass

    def eliminar(self, ):
        pass

    def cobrar(self, ):
        pass

