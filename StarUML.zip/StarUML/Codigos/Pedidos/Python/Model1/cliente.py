#!/usr/bin/python
#-*- coding: utf-8 -*-

class cliente:
    def __init__(self):
        self.id_cliente = None
        self.nombre = None
        self.domicilio = None
        self.telefono = None
        self.email = None

    def editar_cuenta(self, ):
        pass

    def realizar_pedido(self, ):
        pass

    def estado_pedido(self, ):
        pass

    def rechazar_pedido(self, ):
        pass

