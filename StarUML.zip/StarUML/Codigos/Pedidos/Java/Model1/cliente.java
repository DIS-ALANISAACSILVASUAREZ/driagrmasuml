
import java.util.*;

/**
 * 
 */
public class cliente {

    /**
     * Default constructor
     */
    public cliente() {
    }

    /**
     * 
     */
    public void id_cliente;

    /**
     * 
     */
    public void nombre;

    /**
     * 
     */
    public void domicilio;

    /**
     * 
     */
    public void telefono;

    /**
     * 
     */
    public void email;


    /**
     * 
     */
    public void editar_cuenta() {
        // TODO implement here
    }

    /**
     * 
     */
    public void realizar_pedido() {
        // TODO implement here
    }

    /**
     * 
     */
    public void estado_pedido() {
        // TODO implement here
    }

    /**
     * 
     */
    public void rechazar_pedido() {
        // TODO implement here
    }

}