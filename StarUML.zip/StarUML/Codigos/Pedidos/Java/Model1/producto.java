
import java.util.*;

/**
 * 
 */
public class producto {

    /**
     * Default constructor
     */
    public producto() {
    }

    /**
     * 
     */
    public void nombre;

    /**
     * 
     */
    public void precio;

    /**
     * 
     */
    public void marca;

    /**
     * 
     */
    public void stock;

    /**
     * 
     */
    public void descripcion;

    /**
     * 
     */
    public void modificar_stock() {
        // TODO implement here
    }

}