
import java.util.*;

/**
 * 
 */
public class sistema {

    /**
     * Default constructor
     */
    public sistema() {
    }


    /**
     * 
     */
    public void verificar_datos() {
        // TODO implement here
    }

    /**
     * 
     */
    public void acceso_cuenta() {
        // TODO implement here
    }

}