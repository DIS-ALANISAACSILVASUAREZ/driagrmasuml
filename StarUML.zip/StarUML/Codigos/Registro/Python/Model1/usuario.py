#!/usr/bin/python
#-*- coding: utf-8 -*-

class usuario:
    def __init__(self):
        self.nombre = None
        self.direccion = None
        self.telefono = None
        self.email = None
        self.codigo_postal = None

